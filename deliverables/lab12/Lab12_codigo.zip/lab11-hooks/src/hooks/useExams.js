import { useCallback, useEffect, useState } from "react";

// The three states of the lab 12 (loading, ready, error) for the exams list, with a stable
// reload and cancellation of stale responses. Same contract as usePlans, keyed by exams.
export default function useExams(fetchExams) {
  const [state, setState] = useState({ status: "loading", exams: [], error: null });
  const [revision, setRevision] = useState(0);
  const reload = useCallback(() => setRevision((current) => current + 1), []);

  useEffect(() => {
    let cancelled = false;
    setState({ status: "loading", exams: [], error: null });

    async function load() {
      try {
        const exams = await fetchExams();
        if (!cancelled) setState({ status: "ready", exams, error: null });
      } catch (error) {
        if (!cancelled) setState({ status: "error", exams: [], error });
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [fetchExams, revision]);

  return { ...state, reload };
}
