import { StrictMode } from "react";
import { act, renderHook } from "@testing-library/react";
import useExams from "@hooks/useExams";
import { deferred } from "./fixtures";

// The three states of the lab 12 list: loading, ready and error, plus reload and stale answers.
const examsA = [
  { id: 1, title: "Django · ORM", question_count: 4 },
  { id: 2, title: "Django · APIs", question_count: 3 },
];

const examsB = [{ id: 3, title: "Django · Seguridad", question_count: 2 }];

const resolveWith = (request, value) =>
  act(async () => {
    request.resolve(value);
  });
const rejectWith = (request, error) =>
  act(async () => {
    request.reject(error);
  });

function fakeFetch(...requests) {
  const fetchExams = vi.fn();
  requests.forEach((request) => fetchExams.mockReturnValueOnce(request.promise));
  return fetchExams;
}

describe("useExams · los tres estados", () => {
  it("empieza en loading, sin exámenes ni error, y pide los exámenes al montar", () => {
    const request = deferred();
    const fetchExams = fakeFetch(request);
    const { result } = renderHook(() => useExams(fetchExams));

    expect(fetchExams).toHaveBeenCalledTimes(1);
    expect(result.current.status).toBe("loading");
    expect(result.current.exams).toEqual([]);
    expect(result.current.error).toBeNull();
    expect(typeof result.current.reload).toBe("function");
  });

  it("al llegar los exámenes pasa a ready con los exámenes y sin error", async () => {
    const request = deferred();
    const fetchExams = fakeFetch(request);
    const { result } = renderHook(() => useExams(fetchExams));
    await resolveWith(request, examsA);

    expect(result.current.status).toBe("ready");
    expect(result.current.exams).toEqual(examsA);
    expect(result.current.error).toBeNull();
  });

  it("si la petición falla pasa a error, con el error y sin exámenes", async () => {
    const request = deferred();
    const fetchExams = fakeFetch(request);
    const { result } = renderHook(() => useExams(fetchExams));
    const failure = new Error("Sin conexión con la API del curso");
    await rejectWith(request, failure);

    expect(result.current.status).toBe("error");
    expect(result.current.error).toBe(failure);
    expect(result.current.exams).toEqual([]);
  });

  it("no pide los exámenes otra vez en cada dibujado", async () => {
    const request = deferred();
    const fetchExams = fakeFetch(request);
    const { result, rerender } = renderHook(() => useExams(fetchExams));
    await resolveWith(request, examsA);
    rerender();
    rerender();
    expect(fetchExams).toHaveBeenCalledTimes(1);
  });
});

describe("useExams · reload", () => {
  it("reload() vuelve a loading, pide otra vez y termina en ready con los exámenes nuevos", async () => {
    const first = deferred();
    const second = deferred();
    const fetchExams = fakeFetch(first, second);
    const { result } = renderHook(() => useExams(fetchExams));
    await resolveWith(first, examsA);

    act(() => result.current.reload());
    expect(fetchExams).toHaveBeenCalledTimes(2);
    expect(result.current.status).toBe("loading");
    expect(result.current.exams).toEqual([]);

    await resolveWith(second, examsB);
    expect(result.current.status).toBe("ready");
    expect(result.current.exams).toEqual(examsB);
  });

  it("después de un error, reload() limpia el error y puede terminar bien", async () => {
    const first = deferred();
    const second = deferred();
    const fetchExams = fakeFetch(first, second);
    const { result } = renderHook(() => useExams(fetchExams));
    await rejectWith(first, new Error("Sin conexión"));
    expect(result.current.status).toBe("error");

    act(() => result.current.reload());
    expect(result.current.status).toBe("loading");
    expect(result.current.error).toBeNull();

    await resolveWith(second, examsA);
    expect(result.current.status).toBe("ready");
    expect(result.current.exams).toEqual(examsA);
  });
});

describe("useExams · ignora la respuesta vieja (carrera de peticiones)", () => {
  it("si la primera respuesta llega DESPUÉS de la segunda, no pisa a la nueva", async () => {
    const first = deferred();
    const second = deferred();
    const fetchExams = fakeFetch(first, second);
    const { result } = renderHook(() => useExams(fetchExams));

    act(() => result.current.reload());
    await resolveWith(second, examsB);
    expect(result.current.exams).toEqual(examsB);

    await resolveWith(first, examsA);
    expect(result.current.status).toBe("ready");
    expect(result.current.exams).toEqual(examsB);
  });

  it("con StrictMode (como en desarrollo) el efecto corre dos veces y gana la respuesta de la segunda", async () => {
    const first = deferred();
    const second = deferred();
    const fetchExams = fakeFetch(first, second);
    const { result } = renderHook(() => useExams(fetchExams), { wrapper: StrictMode });
    expect(fetchExams).toHaveBeenCalledTimes(2);

    await resolveWith(second, examsB);
    await resolveWith(first, examsA);

    expect(result.current.status).toBe("ready");
    expect(result.current.exams).toEqual(examsB);
  });
});

describe("useExams · desmontar", () => {
  it("si la respuesta llega después de desmontar, no pasa nada", async () => {
    const request = deferred();
    const fetchExams = fakeFetch(request);
    const { unmount } = renderHook(() => useExams(fetchExams));
    unmount();
    await expect(resolveWith(request, examsA)).resolves.not.toThrow();
  });
});
