import { useCallback, useEffect, useState } from "react";

export default function usePlans(fetchPlans) {
  const [state, setState] = useState({ status: "loading", plans: [], error: null });
  const [revision, setRevision] = useState(0);
  const reload = useCallback(() => setRevision((current) => current + 1), []);

  useEffect(() => {
    let cancelled = false;
    setState({ status: "loading", plans: [], error: null });

    async function load() {
      try {
        const plans = await fetchPlans();
        if (!cancelled) setState({ status: "ready", plans, error: null });
      } catch (error) {
        if (!cancelled) setState({ status: "error", plans: [], error });
      }
    }

    load();
    return () => { cancelled = true; };
  }, [fetchPlans, revision]);

  return { ...state, reload };
}
