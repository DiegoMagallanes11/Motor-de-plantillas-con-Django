import Button from "./Button";
import "./ExamsList.css";

// The list of exams the person can delete (lab 12): table-like rows with the real data, the
// count of questions of each exam and a delete action that asks the API to remove it.
export default function ExamsList({ exams, deletingId, onDelete }) {
  const safeExams = Array.isArray(exams) ? exams : [];

  if (safeExams.length === 0) {
    return (
      <div className="exams__empty" role="status">
        <h3>No hay exámenes registrados</h3>
        <p>Crea el primero con el formulario de esta sección.</p>
      </div>
    );
  }

  return (
    <div className="exams">
      <ul className="exams__list">
        {safeExams.map((exam) => (
          <li key={exam.id} className="exams__row" data-exam-id={exam.id}>
            <span className="exams__title">{exam.title}</span>
            <span className="exams__meta">{exam.question_count ?? 0} preguntas</span>
            <span className="exams__meta">{exam.created_at ? new Date(exam.created_at).toLocaleDateString("es-PE") : ""}</span>
            <Button
              variant="danger"
              className="exams__delete"
              disabled={deletingId === exam.id}
              onClick={() => onDelete(exam.id)}
            >
              {deletingId === exam.id ? "Eliminando…" : "Eliminar"}
            </Button>
          </li>
        ))}
      </ul>
    </div>
  );
}
