import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import ExamsList from "../components/ExamsList";

const exams = [
  { id: 1, title: "Django · ORM", question_count: 4, created_at: "2026-11-01T10:00:00Z" },
  { id: 2, title: "Django · APIs", question_count: 3, created_at: "2026-11-02T10:00:00Z" },
];

describe("ExamsList · los tres usos de la lista", () => {
  it("con datos muestra los exámenes con su número de preguntas y fecha", () => {
    render(<ExamsList exams={exams} deletingId={null} onDelete={vi.fn()} />);
    expect(screen.getByText("Django · ORM")).toBeInTheDocument();
    expect(screen.getByText("Django · APIs")).toBeInTheDocument();
    expect(screen.getByText("4 preguntas")).toBeInTheDocument();
    expect(screen.getByText("3 preguntas")).toBeInTheDocument();
    expect(screen.getAllByText("Eliminar")).toHaveLength(2);
  });

  it("con lista vacía muestra el estado vacío", () => {
    render(<ExamsList exams={[]} deletingId={null} onDelete={vi.fn()} />);
    expect(screen.getByText("No hay exámenes registrados")).toBeInTheDocument();
  });

  it("pide eliminar con el id del examen y deshabilita mientras elimina", async () => {
    const user = userEvent.setup();
    const onDelete = vi.fn();
    render(<ExamsList exams={exams} deletingId={1} onDelete={onDelete} />);
    const remove = screen.getByRole("button", { name: "Eliminando…" });
    expect(remove).toBeDisabled();
    await user.click(screen.getByRole("button", { name: "Eliminar" }));
    expect(onDelete).toHaveBeenCalledWith(2);
  });
});
