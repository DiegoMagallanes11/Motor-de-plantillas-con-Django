import { useState } from "react";
import Button from "./Button";
import "./ExamForm.css";

// The create form of the lab 12: controlled input, submit prevention, POST body and validation
// errors (client side first, server side through the error returned by the API).
export default function ExamForm({ onCreate, creating = false, onCreated }) {
  const [title, setTitle] = useState("");
  const [formError, setFormError] = useState(null);
  const [busy, setBusy] = useState(false);

  async function handleSubmit(event) {
    event.preventDefault();
    const value = title.trim();
    if (!value) {
      setFormError("El título del examen es requerido.");
      return;
    }
    if (value.length > 120) {
      setFormError("El título no puede superar los 120 caracteres.");
      return;
    }
    setBusy(true);
    setFormError(null);
    try {
      await onCreate(value);
      setTitle("");
      if (onCreated) onCreated();
    } catch (error) {
      setFormError(error?.response?.data?.title?.[0] ?? error?.message ?? "No se pudo crear el examen.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="exam-form" onSubmit={handleSubmit}>
      <label htmlFor="exam-title">Título del nuevo examen</label>
      <div className="exam-form__row">
        <input
          id="exam-title"
          name="title"
          type="text"
          value={title}
          onChange={(event) => setTitle(event.target.value)}
          placeholder="Ej.: Django · APIs"
          maxLength={120}
        />
        <Button type="submit" disabled={busy || creating}>
          {busy || creating ? "Creando…" : "Crear examen"}
        </Button>
      </div>
      {formError && (
        <p className="exam-form__error" role="alert">
          {formError}
        </p>
      )}
    </form>
  );
}
