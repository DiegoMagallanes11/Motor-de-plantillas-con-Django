// What the person sees while the exams are being fetched from the API (lab 12 loading state).
export default function ExamsSkeleton() {
  return (
    <div className="skeleton" role="status" aria-label="Cargando exámenes">
      {[0, 1, 2].map((n) => (
        <div key={n} className="skeleton-card" aria-hidden="true">
          <span className="skeleton-line skeleton-title" />
          <span className="skeleton-line" />
          <span className="skeleton-line skeleton-short" />
        </div>
      ))}
    </div>
  );
}
