import Button from "./Button";

// What the person sees when a list could not be loaded. The title is optional so the same
// component serves the plans of the week 11 and the exams of the lab 12.
export default function ErrorBanner({ error, onRetry, title = "No se pudieron cargar los datos." }) {
  return (
    <div className="error-banner" role="alert">
      <p>
        <strong>{title}</strong> {error?.message}
      </p>
      <Button variant="ghost" onClick={onRetry}>
        Reintentar
      </Button>
    </div>
  );
}
