import { act, fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import ExamForm from "../components/ExamForm";

describe("ExamForm · crear examen (lab 12)", () => {
  it("no envía con el título vacío y muestra el error de validación", async () => {
    const user = userEvent.setup();
    const onCreate = vi.fn();
    const onCreated = vi.fn();
    render(<ExamForm onCreate={onCreate} onCreated={onCreated} />);

    await user.click(screen.getByRole("button", { name: "Crear examen" }));
    expect(onCreate).not.toHaveBeenCalled();
    expect(screen.getByText("El título del examen es requerido.")).toBeInTheDocument();
  });

  it("con el título escrito envía el POST al crear y vuelve a la lista", async () => {
    const user = userEvent.setup();
    const onCreate = vi.fn().mockResolvedValue({ id: 7, title: "Django · APIs" });
    const onCreated = vi.fn();
    render(<ExamForm onCreate={onCreate} onCreated={onCreated} />);

    await user.type(screen.getByLabelText(/título del nuevo examen/i), "  Django · APIs  ");
    await user.click(screen.getByRole("button", { name: "Crear examen" }));

    expect(onCreate).toHaveBeenCalledWith("Django · APIs");
    expect(onCreated).toHaveBeenCalledTimes(1);
    expect(screen.getByLabelText(/título del nuevo examen/i)).toHaveValue("");
  });

  it("muestra el error que devuelve la API cuando el POST falla", async () => {
    const user = userEvent.setup();
    const onCreate = vi.fn().mockRejectedValue({ response: { data: { title: ["El título ya existe."] } } });
    render(<ExamForm onCreate={onCreate} />);

    await user.type(screen.getByLabelText(/título del nuevo examen/i), "Django · ORM");
    await user.click(screen.getByRole("button", { name: "Crear examen" }));

    expect(await screen.findByText("El título ya existe.")).toBeInTheDocument();
  });
});
