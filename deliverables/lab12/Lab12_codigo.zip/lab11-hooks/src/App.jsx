import { useEffect, useState } from "react";
import ErrorBanner from "./components/ErrorBanner";
import ExamsList from "./components/ExamsList";
import ExamForm from "./components/ExamForm";
import ExamsSkeleton from "./components/ExamsSkeleton";
import Header from "./components/Header";
import Inbox from "./components/Inbox";
import PlansSkeleton from "./components/PlansSkeleton";
import useExams from "@hooks/useExams";
import usePlans from "@hooks/usePlans";
import { createExam, deleteExam, fetchExams as defaultFetchExams, fetchPlans as defaultFetchPlans, network, runAgent as defaultRunAgent } from "./lib/api";
import { readStoredDecisions, writeStoredDecisions } from "./lib/storage";

// The lab 12 keeps the week 11 agent inbox and adds the exams CRUD against the real API:
// one axios client, the three states (loading / data / error) and create + delete flows.
export default function App({
  fetchPlans = defaultFetchPlans,
  runAgent = defaultRunAgent,
  fetchExams = defaultFetchExams,
}) {
  const { status, plans, error, reload } = usePlans(fetchPlans);
  const { status: examsStatus, exams, error: examsError, reload: reloadExams } = useExams(fetchExams);
  const [decisions, setDecisions] = useState(readStoredDecisions);
  const [failing, setFailing] = useState(network.failing);
  const [creating, setCreating] = useState(false);
  const [deletingId, setDeletingId] = useState(null);

  useEffect(() => {
    writeStoredDecisions(decisions);
  }, [decisions]);

  function decide(id, verdict) {
    setDecisions((current) => ({ ...current, [id]: verdict }));
  }

  function toggleFailing(event) {
    setFailing(event.target.checked);
    network.failing = event.target.checked;
  }

  async function handleCreate(title) {
    return createExam({ title });
  }

  async function handleDelete(id) {
    setDeletingId(id);
    try {
      await deleteExam(id);
    } finally {
      setDeletingId(null);
      reloadExams();
    }
  }

  // Derived on every render, never stored. The header receives only this number.
  const pendingCount = status === "ready" ? plans.filter((plan) => !(plan.id in decisions)).length : null;

  return (
    <main className="app">
      <Header pendingCount={pendingCount} />

      <div className="toolbar">
        <label className="network-toggle">
          <input type="checkbox" checked={failing} onChange={toggleFailing} />
          Simular fallo de red
        </label>
        <button type="button" className="reload-link" onClick={reload}>
          Recargar planes
        </button>
      </div>

      {status === "loading" && <PlansSkeleton />}
      {status === "error" && <ErrorBanner error={error} onRetry={reload} title="No se pudieron cargar los planes." />}
      {status === "ready" && <Inbox plans={plans} decisions={decisions} onDecide={decide} runAgent={runAgent} />}

      <section className="exams-section" aria-labelledby="exams-title">
        <div className="exams-section__head">
          <h2 id="exams-title">Exámenes</h2>
          <button type="button" className="reload-link" onClick={reloadExams}>
            Recargar exámenes
          </button>
        </div>

        {examsStatus === "loading" && <ExamsSkeleton />}
        {examsStatus === "error" && <ErrorBanner error={examsError} onRetry={reloadExams} title="No se pudieron cargar los exámenes." />}
        {examsStatus === "ready" && (
          <>
            <ExamsList exams={exams} deletingId={deletingId} onDelete={handleDelete} />
            <ExamForm onCreate={handleCreate} creating={creating} onCreated={() => { setCreating(false); reloadExams(); }} />
          </>
        )}
      </section>
    </main>
  );
}
